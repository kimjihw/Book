package com.example.book.navigation.model

data class ContentDTO(
	var diary: String? = null, // 설명 관리
	var imageUrl : String? = null,
	var uid: String? = null, // 어떤 유저가 올렸는지
	var userId: String? = null, // 유저 아이디
	var timestamp: Long? = null, // 시간
	var favoriteCount: Int = 0, // 몇 명이 좋아요를 눌렀는지
	var favorites: MutableMap<String, Boolean> = HashMap(), // 누가 좋아요를 눌렀는지
	var music : String ? = null
) {
	data class Comment(
		var uid: String? = null, // 누가 댓글을 남겼는지
		var userId: String? = null, // 댓글을 남긴 유저의 아이디
		var comment: String? = null, //뭐라고 남겼는지
		var timestamp: Long? = null // 시간
	)
}