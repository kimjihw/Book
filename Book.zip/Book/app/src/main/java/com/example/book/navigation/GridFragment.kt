package com.example.book.navigation

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.book.R
import com.google.firebase.firestore.FirebaseFirestore

class GridFragment : Fragment(){

	var firestore: FirebaseFirestore? = null
	var uid : String? = null
	override fun onCreateView(
		inflater: LayoutInflater,
		container: ViewGroup?,
		savedInstanceState: Bundle?
	): View? {
		var view = LayoutInflater.from(activity).inflate(R.layout.fragment_alarm, container, false)
		return view
	}
}